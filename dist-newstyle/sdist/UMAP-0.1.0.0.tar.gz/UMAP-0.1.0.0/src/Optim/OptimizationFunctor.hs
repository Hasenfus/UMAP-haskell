module Optim.OptimizationFunctor where

