module Main where

main :: IO ()
main = do
  

